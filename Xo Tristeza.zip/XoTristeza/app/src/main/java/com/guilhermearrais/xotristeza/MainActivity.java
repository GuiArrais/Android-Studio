package com.guilhermearrais.xotristeza;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private ImageView ivSmile;
    private TextView tvNumero;
    private Button btCliqueAqui;

    private int contador = 0;
    private final String TAG = "Clique"; // final -> CONSTANTE


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        ivSmile = findViewById(R.id.iv_smile);
        tvNumero = findViewById(R.id.tv_numero);
        btCliqueAqui = findViewById(R.id.bt_clique_aqui);

        contarEMudarSmile();
    } // Fim do OnCreate()

    private void contarEMudarSmile() {
        btCliqueAqui.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                contador ++;
                //Log.d(TAG, "onClick: CLICOU " + contador);
                tvNumero.setText( String.valueOf( contador ));

                switch ( contador ) {
                    case 10:
                        ivSmile.setImageResource(R.drawable.smile02);
                        break;
                    case 20:
                        ivSmile.setImageResource(R.drawable.smile03);
                        break;
                    case 30:
                        ivSmile.setImageResource(R.drawable.smile04);
                        break;
                    case 40:
                        ivSmile.setImageResource(R.drawable.smile05);
                        break;
                    case 50:
                        ivSmile.setImageResource(R.drawable.smile06);
                        break;
                    case 60:
                        ivSmile.setImageResource(R.drawable.smile07);
                        break;
                    case 70:
                        ivSmile.setImageResource(R.drawable.smile08);
                        break;
                    case 80:
                        ivSmile.setImageResource(R.drawable.smile09);
                        break;
                    case 90:
                        ivSmile.setImageResource(R.drawable.smile10);
                        break;
                    case 100:
                        ivSmile.setImageResource(R.drawable.smile11);
                        break;
                } // Fim do switch

            }
        });
    } // Fim do contarEMudarSmile

    public void zerarTudio (View view ) {
        contador = 0;
        tvNumero.setText( String.valueOf( contador ));
        ivSmile.setImageResource(R.drawable.smile01);
    }
}