package com.guilhermearrais.armazenamentointerno;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class MainActivity extends AppCompatActivity {

    private static final String FILE_NAME = "dados.txt";
    private static final String TEXT_VIEW_STATE = "textViewState.txt";
    private EditText etEntradaMsg;
    private TextView tvExibeMsg;
    private Button btSalvar;
    private Button btCarregar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        etEntradaMsg = findViewById(R.id.et_entrada_msg);
        tvExibeMsg = findViewById(R.id.tv_exibe_msg);
        btSalvar = findViewById(R.id.bt_salvar);
        btCarregar = findViewById(R.id.bt_carregar);

        btSalvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                salvarDados();
            }
        });

        btCarregar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                carregarDados();
            }
        });
    }

    private void salvarDados() {
        String mensagem = etEntradaMsg.getText().toString();
        try (FileOutputStream fos = openFileOutput(FILE_NAME, MODE_PRIVATE)) { // cria um arquivo que vai salvar os dados
            fos.write(mensagem.getBytes()); // salva os dados no arquivo
            etEntradaMsg.setText(""); // apagando a mensagem do EditText
            tvExibeMsg.setText("Mensagem salva com sucesso"); // exibe a mensagem no TextView
        } catch ( IOException e ) {
            e.printStackTrace();
            tvExibeMsg.setText("Erro ao salvar a mensagem."); // exibe a mensagem caso aconteça um erro
        }
    }

    private void carregarDados() {
        try (FileInputStream fis = openFileInput(FILE_NAME)) { // acessando o arquivo com os dados
            int size = fis.available(); // busca o tamanho do dado
            byte[] buffer = new byte[size]; // cria vetor para salvar os dados
            fis.read(buffer); // executa a leitura do arquivo de dados e salva no buffer
            String mensagem = new String(buffer); // carrego os dados do buffer em uma String
            tvExibeMsg.setText(mensagem); // exibir a mensagem para o usuário no TextView
        } catch ( IOException e ) {
            e.printStackTrace();
            tvExibeMsg.setText("Erro ao carregar a mensagem.");
        }

    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outstate) {
        super.onSaveInstanceState(outstate);
        // salva o estado do Textiew no Bundle
        outstate.putString(TEXT_VIEW_STATE, tvExibeMsg.getText().toString());
    }

    @Override
    protected void onRestoreInstanceState(@NonNull Bundle saveInstanceState) {
        super.onRestoreInstanceState(saveInstanceState);
        // restaura o estado do TextView após a rotação
        if ( saveInstanceState != null ) {
            tvExibeMsg.setText(saveInstanceState.getString(TEXT_VIEW_STATE));
        }
    }

}