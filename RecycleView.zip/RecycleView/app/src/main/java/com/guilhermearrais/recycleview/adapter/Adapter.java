package com.guilhermearrais.recycleview.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.guilhermearrais.recycleview.R;
import com.guilhermearrais.recycleview.model.Disciplina;

import java.util.List;

public class Adapter extends RecyclerView.Adapter<Adapter.MyViewHolder> {

    private List<Disciplina> listaDisciplinas;

    public Adapter(List<Disciplina> lista) {
        this.listaDisciplinas = lista;
    }

    @NonNull
    @Override
    public com.guilhermearrais.recycleview.adapter.Adapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        //Cria a vizualização dos itens da lista
        View itemLista = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_lista, parent, false);
        return null;
    }

    @Override
    public int getItemCount() {
        //Quantidade de itens a ser exibido
        return listaDisciplinas.size();
    }

    @Override
    public void onBindViewHolder(@NonNull com.guilhermearrais.recycleview.adapter.Adapter.MyViewHolder holder, int position) {
        //Exibe os itens da lista
        Disciplina d = listaDisciplinas.get( position );
        holder.disciplina.setText( d.getNomeDisciplina() );
        holder.professor.setText( d.getProfessor() );
        holder.diaSemana.setText( d.getDiaSemana() );
        holder.sala.setText( d.getSala() );

    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {

        TextView disciplina;
        TextView professor;
        TextView diaSemana;
        TextView sala;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            disciplina = itemView.findViewById(R.id.tv_disciplina);
            professor = itemView.findViewById(R.id.tv_professor);
            diaSemana = itemView.findViewById(R.id.tv_dia_semana);
            sala = itemView.findViewById(R.id.tv_sala);
        }
    }
}
